package com.bc181.negara;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class DatabaseHandler extends SQLiteOpenHelper {

    private final static int DATABASE_VERSION = 1;
    private final static String DATABASE_NAME = "db_beritaku";
    private final static String TABLE_BERITA = "t_berita";
    private final static String KEY_ID_BERITA = "ID_Berita";
    private final static String KEY_JUDUL = "Judul";
    private final static String KEY_TGL = "Tanggal";
    private final static String KEY_GAMBAR = "Gambar";
    private final static String KEY_CAPTION = "Caption";
    private final static String KEY_PENULIS = "Penulis";
    private final static String KEY_ISI_BERITA ="Isi_Berita";
    private final static String KEY_LINK = "Link";
    private SimpleDateFormat sdFormat = new SimpleDateFormat("dd/mm/yyyy hh:mm", Locale.getDefault());
    private Context context;

    public DatabaseHandler(Context ctx) {
        super(ctx,DATABASE_NAME,null,DATABASE_VERSION);
        this.context = ctx;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_BERITA = "CREATE TABLE " + TABLE_BERITA
                + "(" + KEY_ID_BERITA + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_JUDUL +  " TEXT, " + KEY_TGL + " DATE, "
                + KEY_GAMBAR + " TEXT, " + KEY_CAPTION + " TEXT, "
                + KEY_PENULIS + " TEXT, " + KEY_ISI_BERITA + " TEXT, "
                + KEY_LINK + " TEXT);";

        db.execSQL(CREATE_TABLE_BERITA);
        inisialisasiBeritaAwal(db);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String DROP_TABLE = "DROP TABLE IF EXISTS " + TABLE_BERITA;
        db.execSQL(DROP_TABLE);
        onCreate(db);

    }

    public void tambahBerita(Berita dataBerita){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(KEY_JUDUL, dataBerita.getJudul());
        cv.put(KEY_TGL, sdFormat.format(dataBerita.getTanggal()));
        cv.put(KEY_GAMBAR,dataBerita.getGambar());
        cv.put(KEY_CAPTION,dataBerita.getCaption());
        cv.put(KEY_PENULIS,dataBerita.getPenulis());
        cv.put(KEY_ISI_BERITA,dataBerita.getIsiBerita());
        cv.put(KEY_LINK,dataBerita.getLink());

        db.insert(TABLE_BERITA, null,cv);

    }

    public void tambahBerita(Berita dataBerita,SQLiteDatabase db){
        ContentValues cv = new ContentValues();

        cv.put(KEY_JUDUL, dataBerita.getJudul());
        cv.put(KEY_TGL, sdFormat.format(dataBerita.getTanggal()));
        cv.put(KEY_GAMBAR,dataBerita.getGambar());
        cv.put(KEY_CAPTION,dataBerita.getCaption());
        cv.put(KEY_PENULIS,dataBerita.getPenulis());
        cv.put(KEY_ISI_BERITA,dataBerita.getIsiBerita());
        cv.put(KEY_LINK,dataBerita.getLink());

        db.insert(TABLE_BERITA, null,cv);

    }
    public void editBerita(Berita dataBerita){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(KEY_JUDUL, dataBerita.getJudul());
        cv.put(KEY_TGL, sdFormat.format(dataBerita.getTanggal()));
        cv.put(KEY_GAMBAR,dataBerita.getGambar());
        cv.put(KEY_CAPTION,dataBerita.getCaption());
        cv.put(KEY_PENULIS,dataBerita.getPenulis());
        cv.put(KEY_ISI_BERITA,dataBerita.getIsiBerita());
        cv.put(KEY_LINK,dataBerita.getLink());

        db.update(TABLE_BERITA, cv, KEY_ID_BERITA + "=?" , new String[]{String.valueOf(dataBerita.getIdBerita())});
        db.close();

    }

    public void hapusBerita(int idBerita){
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_BERITA, KEY_ID_BERITA + "=?", new String[]{String.valueOf(idBerita)});
        db.close();
    }

    public ArrayList<Berita> getAllBerita(){
        ArrayList<Berita> dataBerita = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_BERITA;
        SQLiteDatabase db = getReadableDatabase();
        Cursor csr = db.rawQuery(query, null);
        if (csr.moveToFirst()){
            do{
                Date tempDate = new Date();
                try{
                    tempDate = sdFormat.parse(csr.getString(2));
                }catch (ParseException er){
                    er.printStackTrace();
                }

                Berita tempBerita = new Berita(
                        csr.getInt(0),
                        csr.getString(1),
                        tempDate,
                        csr.getString(3),
                        csr.getString(4),
                        csr.getString(5),
                        csr.getString(6),
                        csr.getString(7)
                );

                dataBerita.add(tempBerita);
            }while (csr.moveToNext());
        }
        return dataBerita;
    }

    private String storeImageFile(int id){
        String location;
        Bitmap image = BitmapFactory.decodeResource(context.getResources(),id);
        location = InputActivity.saveImageToInternalStorage(image, context);
        return location;
    }

    private void  inisialisasiBeritaAwal(SQLiteDatabase db) {
        int idBerita = 0;
        Date tempDate = new Date();

        //Menambah data berita ke -1
        try{
            tempDate = sdFormat.parse( "01/12/2017 06:22");
        }catch(ParseException er){
            er.printStackTrace();
        }
        Berita berita1 = new Berita(
                idBerita,
                "Dark (2017)",
                tempDate,
                storeImageFile(R.drawable.film1),
                "TV Series Netflix tahun 2017",
                "Baran bo Odar",
                "Dark adalah serial original Netflix yang berbahasa Jerman yang bermula ketika Erik, seorang anak SMA di sebuah kota kecil bernama Winden di Jerman, hilang secara misterius. Lalu, Jonas, salah satu tokoh utama kita pergi bersama teman-temannya untuk mencari paket narkoba yang mungkin ditinggalkan Erik di sebuah goa. Setelah mereka berhasil mendapatkan paket tersebut, suatu kejadian aneh terjadi dan mereka kehilangan satu anggota mereka yang paling kecil, Mikkel, yang juga hilang dengan misterius. Merasa bertanggung jawab, Jonas berusaha mencari keberadaan Mikkel yang membawanya kepada fakta yang mengejutkan tentang kota Winden.\n" +
                        "Cerita seperti ini sudah sering kita lihat di berbagai serial. Sebut saja Stranger Things dan Twin Peaks yang juga bercerita tentang kejadian misterius seperti orang yang hilang atau dibunuh di sebuah kota kecil. Jika di Twin Peaks dan Stranger Things ada pabrik kayu dan Hawkins lab yang menjadi sumber masalah, maka Dark menampilkan reaktor nuklir yang menjadi sumber permasalahan.\n" +
                        "Memang polanya hampir sama, namun Dark menampilkan cerita beserta semua misterinya dengan berbeda. Seperti judulnya, “Dark”, serial ini memiliki seting tempat yang digambarkan tampak selalu mendung. Cocok dengan mood semua pemainnya yang hampir selalu cemberut. Lalu score serial ini juga mencekam. Ini membuat serial ini menarik dan berbeda.\n" +
                        "Ditambah lagi, serial ini mengusung genre sci fi yang menampilkan cerita perjalanan waktu yang membingungkan sekaligus membuat penasaran. Karena ada beberapa karakter yang sama namun ditampilkan dengan pemeran yang berbeda dalam seting waktu yang berbeda pula (baca: versi muda dan tua), maka kamu dipaksa harus mengingat karakter tersebut agar tidak tersesat di tengah cerita. Hal ini membuat penonton menjadi tidak pernah “lepas” dari cerita.\n" +
                        "Dark juga memberikan bumbu drama ala kota kecil sepanjang pengungkapan misteri. Mulai dari perselingkuhan, pengkhianatan, masalah rumah tangga, hingga cinta segi tiga anak SMA. Walau ada beberapa drama yang tidak berhubungan dengan plot, akting apik dan tampilan yang “enak dipandang” dari para pemerannya menjadikan drama itu menarik untuk disimak.\n" +
                        "Serial ini juga pintar menceritakan dan menyembunyikan misteri yang ada. Seperti fenomena alam misterius yang terjadi di mana sekawanan burung dan domba tewas seketika tanpa penyebab yang jelas. Misteri yang disuguhkan dengan pintar diungkap dalam waktu yang cukup lama sehingga penonton betah menunggu bagaimana misteri tersebut dipecahkan.\n" +
                        "Nilai plus dari serial ini adalah membuat wormhole (lorong waktu) yang tampak real karena tidak memakai CGI. Hampir di sepanjang season kita tidak disuguhkan dengan CGI yang bagi sebagian TV series malah membuat cerita menjadi kurang menggigit karena, ya, kualitas CGI yang jelek.\n" +
                        "Dark juga memiliki “villain” yang sangat menarik. Noah, antagonis di serial ini mengingatkan kepada sosok Johan Liebert di manga Monster. Misterius, pendiam, karismatik, dan berbahaya. Dengan balutan cerita perjalanan waktu, karakter misterius ini berhasil membuat kita mengira-ngira siapakah dan apa tujuan dia sebenarnya.\n",
                "https://mariviu.com/review-tv-series-dark/"

        );

        tambahBerita(berita1, db);
        idBerita++;

        // Membentuk obyek data berita 2
        tempDate = new Date();
        try{
            tempDate = sdFormat.parse( "06/05/2019 06:15");
        }catch(ParseException er){
            er.printStackTrace();
        }
        Berita berita2 = new Berita(
                idBerita,
                "Chernobyl (2019)",
                tempDate,
                storeImageFile(R.drawable.film2),
                "TV Series Netflix tahun 2019",
                "Johan Renck",
                "Chernobyl adalah salah satu miniseri yang dirilis HBO. Serial ini bercerita tentang bencana ledakan nuklir paling besar sepanjang sejarah yang pernah terjadi di Ukraina, saat itu masih Uni Soviet.\n" +
                        "Ledakan yang terjadi pada 26 April 1986 ini sebenarnya tidak pernah dipublikasikan karena pemerintah Soviet tak ingin dunia tahu kegagalan mereka dalam pengembangan teknologi reaktor nuklir. Maka ketika miniseri ini dirilis, banyak orang yang akhirnya tersadar bahwa ledakan nuklir terbesar pernah terjadi di Ukraina.\n" +
                        "Ceritanya sendiri digiring oleh narasi Valery Legasov (Jared Harris) yang merasa bahwa pengembangan teknologi reaktor nuklir di negaranya terlalu dipaksakan. Legasov pun akhirnya melakukan penelitian kecil bahwa kegagalan ini akan berimbas besar pada masyarakat.\n" +
                        "Ledakan akhirnya terjadi di sebuah pembangkit tenaga nuklir. Alih-alih dianggap berbahaya, pemerintah menyatakan bahwa peristiwa itu bukan hal yang harus dikhawatirkan.\n" +
                        "Para masyarakat Ukraina pun menikmati ledakan itu karena menghiasi langit Ukraina layaknya pesta kembang api. Permasalahan mulai muncul karena udara di Chernobyl terdampak ledakan itu berbahaya untuk dihirup.\n" +
                        "Meski banyak menggunakan istilah-istilah berbau fisika, miniseri Chernobyl tetap sangat seru untuk ditonton. Akting para pemainnya merata dengan porsi yang pas. Selain itu, setting waktu dan tempat yang disuguhkan benar-benar menggambarkan betapa mencekamnya Chernobyl di tahun 1986. Ketegangan semakin lengkap ketika scoring musik yang disertakan cukup dalam memadukan keseluruhan elemen yang dibangun.\n" +
                        "Selain membawa nafas sejarah yang tak terungkap, Chernobyl juga dijadikan pembelajaran bagi para ilmuwan untuk menciptakan reaktor nuklir yang benar. Peristiwa kematian massal yang terjadi di Ukraina pada 1986 tentunya tidak seharusnya terulang karena kelalaian dari orang-orang yang terlibat di dalamnya.\n",
                "https://celebrity.okezone.com/read/2020/02/17/206/2169642/sinopsis-chernobyl-miniseri-tentang-ledakan-nuklir-di-ukraina?page=2"

        );
        tambahBerita(berita2, db);
        idBerita++;

        // Membentuk obyek data berita 3
        tempDate = new Date();
        try{
            tempDate = sdFormat.parse( "23/01/2019 22:46");
        }catch(ParseException er){
            er.printStackTrace();
        }
        Berita berita3 = new Berita(
                idBerita,
                "Extreme Job (2019)",
                tempDate,
                storeImageFile(R.drawable.film3),
                "Film terkenal di Korea tahun 2019",
                "Lee Byeong-Heon",
                "Film Korea Selatan bergenre komedi, Extreme Job. Film ini disutradarai oleh Lee Byeong Hun, yang juga sutradara beberapa film komedi populer seperti Sunny (2011), Twenty (2015), Love Forceast (2015), dan What a Man Wants (2018). Menurut The Korea Times, film ini mengisahkan tentang lima detektif yang sedang menangani kasus narkoba. Mereka mendirikan restoran ayam bergaya Korea sebagai bagian dari misi penyelidikan dan penyamaran rahasia untuk mengekspos akar kejahatan tersebut. Akan tetapi, beberapa insiden tak terduga mulai terjadi ketika restoran tempat mereka bekerja mulai terkenal. Kelima detektif polisi tersebut adalah ketua tim Go (Ryoo Seung-Ryong), Detektif Jang (Lee Ha Nee/Lee Honey), Detektif Ma (Jin Seon Kyu), Detektif Young Ho (Lee Dong Hwi) dan Detektif Jae Hoon (Gong Myung). Menurut Korean Film Council, film yang tayang perdana di Korea Selatan pada 23 Januari 2019 ini, per 6 Februari telah meraih 10 juta penonton, yaitu dalam kurun waktu 15 hari, seperti melansir Yonhap News Agency. Extreme Job menjadi film Korea Selatan ke-18 dan film komedi kedua yang bisa meraih 10 juta penonton setelah Miracle in Cell No. 7 (2013).\n" +
                        "Film ini meraih review positif dari para kritikus film Korea Selatan karena menyajikan dialog dinamis antar karakternya dan cerita komedi yang mudah ditangkap oleh generasi muda. “Sutradaranya adalah ahli dalam menciptakan lelucon, dan mampu berurusan dengan berbagai tema dan subjek. Extreme Job memiliki permainan kata-kata yang mewah, plot twist dan dialog yang dinamis antar karakternya,\" ujar Kang Yoo Jung, seorang kritikus film seperti melansir The Korea Times. \"Dalam beberapa tahun terakhir, bioskop Korea cenderung fokus menangani masalah sosial dalam kejahatan besar dan kebenarannya diungkap dalam film. Dalam melakukannya, mereka menghasilkan skenario yang kurang detail,” sambungnya. “Tetapi seperti Mal-Mo-E, khalayak sekarang memiliki pandangan yang tajam untuk lebih suka karya sutradara yang mungkin kurang dikenal tetapi memiliki cara unik mereka sendiri untuk membuat cerita,” \"Film ini menanamkan humor di mana-mana, sehingga pemirsa dapat tertawa terbahak-bahak setiap satu atau dua menit. Ini cocok untuk generasi muda yang terbiasa menonton video klip pendek di YouTube, yang dibuat untuk mengarahkan penonton tertawa secara instan,” ujar kritikus film lainnya, Yoon Seung Eun. “Komedi show di TV seperti ‘Gag Concert’ semakin berkurang karena mereka tidak memahami tren ini, sementara film ini bisa dikatakan sebaliknya,” katanya.\n",
                "https://tirto.id/sinopsis-film-extreme-job-yang-tayang-di-indonesia-20-februari-dgmR"

        );
        tambahBerita(berita3, db);
        idBerita++;

        // Membentuk obyek data berita 4
        tempDate = new Date();
        try{
            tempDate = sdFormat.parse( "17/01/2020 05:58");
        }catch(ParseException er){
            er.printStackTrace();
        }
        Berita berita4 = new Berita(
                idBerita,
                "Dolittle (2020)",
                tempDate,
                storeImageFile(R.drawable.film4),
                "Film Box Office tahun 2020 dengan pemeran utamanya yaitu Robert Downey Jr",
                "Stephen Gaghan",
                "Film petualangan komedi berjudul Dolittle yang baru saja rilis di Indonesia. Film ini menceritakan seorang dokter hewan yang memiliki kemampuan untuk memahami bahasa hewan dan mampu berkomunikasi dengan hewan. Film yang berdurasi 1 jam 41 menit ini merupakan karya sutradara Stephen Gaghan. Ide cerita diangkat dari sebuah buku berjudul The Voyages of Doctor Dolittle karya Hugh Lofting. Tidak hanya itu, film ini juga merupakan reboot dari film Dr. Dolittle (1998). Robert Downey Jr. memainkan peran utama bersama dengan aktor lain seperti Antonia Banderas dan Michael Seen. \n" +
                        "Ada pula aktor dan aktris lain yang menjadi pengisi suara dari hewan-hewan yang berkomunikasi dengan dokter Dolittle seperti Emma Thompson yang memerankan burung macaw, Tom Holland sebagai anjing, Rami Malek sebagai gorilla, John Cen sebagai beruang kutub, Octavia Spencer sebagai bebek, Kumail Nanjiani yang mengisi suara pada burung unta, Selena Gomez pada jerapah dan terakhir Marion Cotillard yang mengisi suara seekor rubah. Film dengan latar belakang Inggris pada abad ke-19 ini cocok dinikmati untuk semua golongan umur. Humor yang dibawakan dapat menjadi sumber tertawa baik untuk anak-anak, remaja, maupun para orang tua. \n" +
                        "Kelompok hewan baik teman maupun lawan, menjadi sumber hiburan dan karakter yang cukup kuat dalam membangun ide cerita di film ini. Mereka membantu dokter Dolittle untuk menjaga reputasinya sebagai dokter yang handal. Sinopsis Film Dolittle Dokter hewan John Dolittle hidup menyendiri setelah kehilangan istrinya yang wafat tujuh tahun yang lalu. Dolittle menutup klinik yang awal mulanya selalu terbuka baik untuk manusia maupun hewan. Ia memilih menyendiri seperti manusia gua dan hidup bersama dengan hewan-hewan peliharaannya yang eksentrik di balik tembok tinggi Dolittle Manor. Suatu hari, sang Ratu muda Victoria (Jessie Buckley) menderita sakit parah. Dolittle yang tidak memiliki motivasi apapun dengan terpaksa mencari obat untuk sang ratu dan berlayar menuju ke sebuah pulau yang penuh mitos. \n" +
                        "Dalam petualangannya, ia sekaligus mendapatkan kembali kecerdasan dan keberaniannya. Tidak hanya itu, ia harus menghadapi bajak laut ganas (Antonio Banderas) beserta hewan-hewan peliharaannya. Musuh bebuyutannya di masa lalu, seorang dokter dari kerajaan Blair Mudfly (Michael Seen) juga menjadi penghalangnya dalam petualangannya mencari obat. Dalam pencariannya, ia didampingi oleh seorang anak magang yang ia tunjuk sendiri yang diperankan oleh Harry Collet. Juga, kelompok hewan eksentrik miliknya yang di dalamnya terdapat seekor gorilla yang mudah panik (Rami Malek), bebek (Octavia spencer), duo burung unta sinis (Kumail Nanjiani), burung kutub yang optimis (John Cena), dan burung beo keras kepala (Emma Thompson).\n",
                "https://tirto.id/sinopsis-dolittle-film-petualangan-fantasi-robert-downey-jr-es2u"
        );
        tambahBerita(berita4, db);
    }

}
